﻿namespace TelegramMvc.Exceptions;

public class TelegramResultNotFoundException : Exception
{
}