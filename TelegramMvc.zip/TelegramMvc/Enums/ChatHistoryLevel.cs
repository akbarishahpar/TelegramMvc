﻿namespace TelegramMvc.Enums;

public enum ChatHistoryLevel
{
    Message,
    MessageAndMarkup,
    None
}