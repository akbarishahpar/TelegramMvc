﻿namespace TelegramMvc.Enums;

public enum MessageDirection
{
    In,
    Out
}